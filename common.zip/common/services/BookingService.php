<?php

declare(strict_types=1);

namespace common\services;

use Yii;
use yii\db\Connection;
use yii\db\Query;

/**
 * Service Layer para lidar com a lógica de disponibilidade e horários.
 * No Yii2, usaremos o componente Db para consultas.
 */

class BookingService
{
    /**
     * @var Connection
     */
    private $db;

    public function __construct()
    {
        // Padrão Yii2: injetar o componente 'db' (conexão com o BD)
        $this->db = Yii::$app->db;
    }

    /**
     * Gera todos os slots possíveis e verifica quais estão ocupados.
     * * @param string $resourceType O tipo de recurso (ex: 'private_office')
     * @param string $date A data no formato 'YYYY-MM-DD'
     * @param int $slotDurationMinutes Duração do slot em minutos.
     * @param string $startHour Hora de início da operação (HH:MM:SS).
     * @param string $endHour Hora final da operação (HH:MM:SS).
     * @return array Lista de slots com status de disponibilidade.
     */
    public function getDailySlots(
        string $resourceType,
        string $date,
        int $slotDurationMinutes = 60, // 60 minutos por padrão
        string $startHour = '07:00:00',
        string $endHour = '21:00:00'
    ): array {
        // 1. Geração de Slots Potenciais
        $allSlots = $this->generatePotentialSlots($date, $startHour, $endHour, $slotDurationMinutes);

        // 2. Consulta ao Banco de Dados (Reservas Existentes)
        // Usamos o Query Builder do Yii2 - Mais seguro e portátil que SQL puro.
        $occupiedSlots = (new Query())
            ->select(['start_at', 'end_at'])
            ->from('bookings')
            ->where([
                'resource_type' => $resourceType,
                // Filtra apenas reservas que interceptam o dia em questão
                'DATE(start_at)' => $date,
            ])
            // Executa a consulta e retorna os resultados como array
            ->all($this->db);

        // 3. Checagem de Conflito e Marcação de Disponibilidade
        foreach ($allSlots as $index => &$slot) {
            $slot['is_available'] = true; // Assume disponível

            // Cria objetos DateTimeImmutable para comparações precisas e seguras
            $slotStart = new \DateTimeImmutable($date . ' ' . $slot['start']);
            $slotEnd = new \DateTimeImmutable($date . ' ' . $slot['end']);

            foreach ($occupiedSlots as $occupied) {
                $occupiedStart = new \DateTimeImmutable($occupied['start_at']);
                $occupiedEnd = new \DateTimeImmutable($occupied['end_at']);

                // Lógica de Sobreposição (Intersection/Conflito)
                // O slot está ocupado se: (slotStart < occupiedEnd) E (slotEnd > occupiedStart)
                if ($slotStart < $occupiedEnd && $slotEnd > $occupiedStart) {
                    $slot['is_available'] = false;
                    break; // Sai do loop de reservas, pois já está ocupado
                }
            }
        }

        // Remove a referência para evitar efeitos colaterais
        unset($slot);

        return $allSlots;
    }

    /**
     * Função auxiliar para gerar todos os intervalos de tempo possíveis.
     * * @param string $date 
     * @param string $startHour 
     * @param string $endHour 
     * @param int $duration
     * @return array
     */
    private function generatePotentialSlots(string $date, string $startHour, string $endHour, int $duration): array
    {
        $slots = [];
        $start = \DateTime::createFromFormat('Y-m-d H:i:s', $date . ' ' . $startHour);
        $end   = \DateTime::createFromFormat('Y-m-d H:i:s', $date . ' ' . $endHour);
        $interval = new \DateInterval('PT' . $duration . 'M'); // Duração do slot

        // Loop que gera os slots: 07:00-08:00, 08:00-09:00, ..., 20:00-21:00
        while ($start < $end) {
            $slotStart = clone $start;
            $start->add($interval); // Avança para o fim do slot

            if ($start > $end) {
                // Não inclui slots que excedem o horário de fechamento (21:00)
                break;
            }

            $slots[] = [
                // Formato exigido pelo Front-end (apenas hora)
                'start' => $slotStart->format('H:i:s'),
                'end' => $start->format('H:i:s'),
                // Formato amigável para exibição
                'display_time' => $slotStart->format('H:i') . ' - ' . $start->format('H:i'),
                'is_available' => true, // Status placeholder
            ];
        }

        return $slots;
    }
}
