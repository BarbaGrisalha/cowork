<?php
$params = array_merge(
    require __DIR__ . '/../../common/config/params.php',
    require __DIR__ . '/../../common/config/params-local.php',
    require __DIR__ . '/params.php',
    require __DIR__ . '/params-local.php'
);

return [
    'id' => 'app-frontend',
    'name' => 'Cowork IPLeiria',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'controllerNamespace' => 'frontend\controllers',
    'modules' => [
        'api' => [
            'class' => 'frontend\modules\api\Module',
            'version' => 'v1', // opcional, mas útil se quiser versionar
        ],
    ],
    'components' => [
        'request' => [
            'csrfParam' => '_csrf-frontend',
        ],
        'user' => [
            'identityClass' => 'common\models\User',
            'enableAutoLogin' => true,
            'identityCookie' => [
                'name' => '_identity-frontend',
                'httpOnly' => true,
            ],
            'loginUrl' => ['auth/portal'],
        ],
        'session' => [
            // Nome do cookie de sessão para o frontend
            'name' => 'advanced-frontend',
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => \yii\log\FileTarget::class,
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'errorHandler' => [
            'errorAction' => 'site/error',
        ],

        // -------------------------------
        // URL Manager: Rotas Bonitas + API
        // -------------------------------
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'rules' => [
                // Rotas REST da API versão 1
                [
                    'class' => 'yii\rest\UrlRule',
                    'controller' =>
                    'api/reservation',
                    'extraPatterns' => [
                        'GET availabity/{resource}/{date}' => 'availabity'
                    ],
                    'tokens' => [],
                    'pluralize' => false, // mantém o formato sem "s" no final
                ],

                // Rotas padrão do site
                '' => 'site/index',
                '<controller:\w+>/<action:\w+>/' => '<controller>/<action>',
            ],
        ],
    ],
    'params' => $params,
];
