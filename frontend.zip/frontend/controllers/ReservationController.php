<?php

namespace frontend\controllers;

use Yii;
use yii\rest\Controller;
use yii\web\Response;
use frontend\models\Reservations; // O modelo que você acabou de gerar com sucesso

class ReservationController extends Controller
{
    // Define o modelo principal para este Controller REST
    public $modelClass = Reservations::class;

    public function init()
    {
        parent::init();
        // Garante que o output é sempre JSON
        Yii::$app->response->format = Response::FORMAT_JSON;
    }

    // Desabilitar o comportamento padrão do REST para usarmos as nossas ações
    public function actions()
    {
        return [];
    }

    /**
     * Ação GET: Obtém eventos para o calendário.
     * EndPoint: GET api/reservations/calendar?start=YYYY-MM-DD&end=YYYY-MM-DD
     */
    public function actionCalendarEvents($start, $end)
    {
        if (empty($start) || empty($end)) {
            Yii::$app->response->statusCode = 400;
            return ['error' => 'Datas de início e fim são obrigatórias.'];
        }

        // Lógica de consulta para sobreposição de datas
        $query = Reservations::find()
            ->where(['<=', 'hora_inicio_agendada', $end])
            ->andWhere(['>=', 'hora_fim_agendada', $start])
            ->with(['room', 'customer']);

        $reservations = $query->all();

        return $reservations;
    }

    /**
     * Ação POST: Cria uma nova reserva. (Próximo Passo)
     */
    public function actionCreate()
    {
        Yii::$app->response->statusCode = 501; // Not Implemented
        return ['error' => 'A lógica de criação de reserva ainda não foi implementada.'];
    }
    /**
     * Ação GET: Obtém horários disponíveis para uma sala específica num dia.
     * EndPoint: GET api/reservations/available-slots?date=YYYY-MM-DD&room_id=X
     *
     * @param string $date A data da consulta (YYYY-MM-DD)
     * @param int $room_id O ID da sala
     * @return array
     * @throws \yii\web\BadRequestHttpException
     */
    public function actionAvailableSlots($date, $room_id)
    {
        if (empty($date) || empty($room_id)) {
            Yii::$app->response->statusCode = 400;
            return ['error' => 'Data e ID da sala são obrigatórios.'];
        }

        // 1. Definir os horários de funcionamento (Ex: 09:00 - 18:00)
        // Idealmente, isto viria da configuração da sala ou da aplicação
        $businessStart = new DateTime($date . ' 09:00:00');
        $businessEnd = new DateTime($date . ' 19:00:00');
        $interval = new DateInterval('PT1H'); // Slots de 1 hora

        // 2. Buscar reservas *existentes* para esta sala neste dia
        $startOfDay = $date . ' 00:00:00';
        $endOfDay = $date . ' 23:59:59';

        $bookedReservations = Reservations::find()
            ->where(['room_id' => $room_id])
            ->andWhere(['<=', 'hora_inicio_agendada', $endOfDay])
            ->andWhere(['>=', 'hora_fim_agendada', $startOfDay])
            ->all();

        // 3. Gerar todos os slots possíveis e verificar a disponibilidade
        $allSlots = new DatePeriod($businessStart, $interval, $businessEnd);
        $availableSlots = [];

        foreach ($allSlots as $slotStart) {
            $slotEnd = (clone $slotStart)->add($interval);
            $isAvailable = true;

            // Verificar conflito com reservas existentes
            foreach ($bookedReservations as $booking) {
                $bookingStart = new DateTime($booking->hora_inicio_agendada);
                $bookingEnd = new DateTime($booking->hora_fim_agendada);

                // Lógica de sobreposição (overlap):
                // O slot começa antes que a reserva termine E o slot termina depois que a reserva começa
                if ($slotStart < $bookingEnd && $slotEnd > $bookingStart) {
                    $isAvailable = false;
                    break; // Conflito encontrado, não precisa verificar mais
                }
            }

            $availableSlots[] = [
                'start' => $slotStart->format('Y-m-d H:i:s'),
                'end'   => $slotEnd->format('Y-m-d H:i:s'),
                'label' => $slotStart->format('H:i') . ' - ' . $slotEnd->format('H:i'), // Para o frontend
                'available' => $isAvailable
            ];
        }

        return $availableSlots;
    }
}
