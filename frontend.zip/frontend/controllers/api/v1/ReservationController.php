<?php

namespace frontend\controllers\api\v1;

use Yii;
use yii\rest\Controller;
use yii\web\Response;
use yii\rest\ActiveController;
use frontend\models\Reservations;

class ReservationController extends ActiveController
{
    public $modelClass = 'frontend\models\Reservations';

    public function behaviors()
    {
        $behaviors = parent::behaviors();
        // Força retorno em JSON
        $behaviors['contentNegotiator']['formats']['application/json'] = Response::FORMAT_JSON;
        return $behaviors;
    }

    /**
     * Retorna os horários disponíveis para um recurso em uma data
     * GET /api/v1/availability/{resource}/{date}
     */
    public function actionAvailability($resource, $date)
    {
        // Todos os slots possíveis (pode vir de config, tabela ou hardcoded)
        $allSlots = [
            ['start' => '08:00:00', 'end' => '09:00:00'],
            ['start' => '09:00:00', 'end' => '10:00:00'],
            ['start' => '10:00:00', 'end' => '11:00:00'],
            ['start' => '11:00:00', 'end' => '12:00:00'],
            ['start' => '14:00:00', 'end' => '15:00:00'],
            ['start' => '15:00:00', 'end' => '16:00:00'],
            ['start' => '16:00:00', 'end' => '17:00:00'],
            ['start' => '17:00:00', 'end' => '18:00:00'],
            ['start' => '18:00:00', 'end' => '19:00:00'],
        ];

        // Busca reservas existentes
        $reserved = Reservations::find()
            ->where(['resource_type' => $resource, 'booking_date' => $date]) //partir da qui. api funcionando. buscar o resourceType
            ->all();

        $result = [];
        foreach ($allSlots as $slot) {
            $isAvailable = true;
            foreach ($reserved as $res) {
                if ($res->start_time == $slot['start']) {
                    $isAvailable = false;
                    break;
                }
            }
            $result[] = [
                'start' => $slot['start'],
                'end' => $slot['end'],
                'display_time' => date('H:i', strtotime($slot['start'])) . ' - ' . date('H:i', strtotime($slot['end'])),
                'is_available' => $isAvailable,
            ];
        }

        return $result;
    }
}
