<?php

namespace frontend\controllers;

use yii\filters\AccessControl;

class DashboardController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }
    public function behaviors(): array
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'rule' => [
                    'allow' => true,
                    'roles' => ['@'],
                ],
            ],
        ];
    }
}
