<?php

//namespace app\models; // A sua namespace original está correta
namespace frontend\models;

use Yii;
use app\models\Room;     // Verifique se este namespace está correto
use app\models\Customer; // Verifique se este namespace está correto
use DateTime; // <<< ADICIONADO: Necessário para lógica de datas

/**
 * This is the model class for table "reservations".
 *
 * @property int $id
 * @property int $customer_id
 * @property int $room_id
 * @property string $data_reserva
 * @property string $hora_inicio_agendada
 * @property string $hora_fim_agendada
 * @property float $total_estimado
 * @property string $status
 * @property string|null $reservation_code // <<< ADICIONADO: Propriedade para o código
 *
 * @property AccessCodes[] $accessCodes
 * @property Customers $customer
 * @property HorariosControle[] $horariosControles
 * @property Invoices[] $invoices
 * @property Economato[] $items
 * @property RoomItems[] $items0
 * @property Payments[] $payments
 * @property ReservationItems[] $reservationItems
 * @property ReservationRoomItems[] $reservationRoomItems
 * @property Rooms $room
 */
class Reservations extends \yii\db\ActiveRecord
{

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'reservations';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['total_estimado'], 'default', 'value' => 0.00],
            [['status'], 'default', 'value' => 'pendente'],
            [['customer_id', 'room_id', 'hora_inicio_agendada', 'hora_fim_agendada'], 'required'],
            [['customer_id', 'room_id'], 'integer'],
            [['data_reserva', 'hora_inicio_agendada', 'hora_fim_agendada'], 'safe'],
            [['total_estimado'], 'number'],
            [['status'], 'string', 'max' => 30],

            // <<< REMOVIDO: Esta regra 'unique' é perigosa e inútil para sobreposições
            // [['room_id', 'hora_inicio_agendada', 'hora_fim_agendada'], 'unique', 'targetAttribute' => ['room_id', 'hora_inicio_agendada', 'hora_fim_agendada']],

            // <<< ADICIONADO: Validação customizada para sobreposição
            ['hora_inicio_agendada', 'validateOverlap'],

            // <<< CORRIGIDO: O targetClass deve ser 'Customer::class' (singular), como nos seus 'use' e 'get'
            [['customer_id'], 'exist', 'skipOnError' => true, 'targetClass' => Customer::class, 'targetAttribute' => ['customer_id' => 'id']],

            // <<< CORRIGIDO: O targetClass deve ser 'Room::class' (singular)
            [['room_id'], 'exist', 'skipOnError' => true, 'targetClass' => Room::class, 'targetAttribute' => ['room_id' => 'id']],

            // <<< ADICIONADO: Regras para o novo código de reserva
            [['reservation_code'], 'string', 'max' => 50],
            [['reservation_code'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'customer_id' => 'Customer ID',
            'room_id' => 'Room ID',
            'data_reserva' => 'Data Reserva',
            'hora_inicio_agendada' => 'Hora Inicio Agendada',
            'hora_fim_agendada' => 'Hora Fim Agendada',
            'total_estimado' => 'Total Estimado',
            'status' => 'Status',
            'reservation_code' => 'Código da Reserva', // <<< ADICIONADO
        ];
    }

    // --- MÉTODOS DE VALIDAÇÃO CUSTOMIZADA ---

    /**
     * Validador customizado para impedir sobreposição de reservas (overlap).
     * Isto é o que impede double-booking.
     *
     * @param string $attribute O atributo sendo validado (hora_inicio_agendada)
     */
    public function validateOverlap($attribute, $params)
    {
        if ($this->hasErrors()) {
            // Não vamos validar se outros erros (ex: 'required') já falharam
            return;
        }

        // Datas da *nova* reserva
        $newStart = $this->hora_inicio_agendada;
        $newEnd = $this->hora_fim_agendada;

        // Garantir que a data final é depois da inicial
        if ($newStart >= $newEnd) {
            $this->addError($attribute, 'A hora de fim deve ser posterior à hora de início.');
            return;
        }

        // A lógica de sobreposição:
        // Encontrar qualquer reserva na MESMA SALA onde:
        // O início (existente) é ANTES do fim (novo) E
        // O fim (existente) é DEPOIS do início (novo)
        $query = Reservations::find()
            ->where(['room_id' => $this->room_id])
            ->andWhere(['<', 'hora_inicio_agendada', $newEnd])
            ->andWhere(['>', 'hora_fim_agendada', $newStart]);

        // Se estivermos a *atualizar* uma reserva (isNewRecord é false),
        // temos que excluir o ID dela da verificação,
        // senão ela vai conflitar consigo mesma.
        if (!$this->isNewRecord) {
            $query->andWhere(['!=', 'id', $this->id]);
        }

        // Se a query retornar *qualquer coisa*, temos um conflito.
        if ($query->exists()) {
            $this->addError($attribute, 'Este horário está em conflito com uma reserva existente para esta sala.');
            $this->addError('hora_fim_agendada', 'Conflito de horário detectado.');
        }
    }

    // --- MÉTODOS DE EVENTOS (HOOKS) ---

    /**
     * afterSave: Disparado após salvar (criar ou atualizar)
     * Usamos isto para gerar o código da reserva após o 'id' existir.
     */
    public function afterSave($insert, $changedAttributes)
    {
        parent::afterSave($insert, $changedAttributes);

        // 'insert' é true apenas na *criação* de um novo registo
        // e verificamos se o código ainda não foi gerado
        if ($insert && empty($this->reservation_code)) {

            // 1. Obter o nome da sala (via relacionamento)
            $room = $this->getRoom()->one(); // ou $this->room
            $roomCode = 'SALA'; // Fallback
            if ($room && !empty($room->nome_sala)) {
                // Limpa o nome para algo "amigável" para IDs (Ex: "Sala 02" -> "SALA02")
                $roomCode = strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', $room->nome_sala));
            } else {
                $roomCode = 'SALA' . $this->room_id; // Se não houver nome, usa o ID
            }

            // 2. Formatar a data (Ex: 20251112)
            $dateCode = (new DateTime($this->hora_inicio_agendada))->format('Ymd');

            // 3. Gerar o código (Ex: RES-20251112-SALA02-123)
            $code = "RES-{$dateCode}-{$roomCode}-{$this->id}";

            // 4. Salvar o código no banco
            // Usamos updateAttributes para salvar *apenas* este campo
            // sem disparar o 'afterSave' novamente (loop infinito)
            $this->updateAttributes(['reservation_code' => $code]);
        }
    }


    // --- MÉTODOS DE RELACIONAMENTO (GETTERS) ---
    // (O seu código original - parecem corretos, assumindo que as classes existem)

    /**
     * Gets query for [[AccessCodes]].
     * @return \yii\db\ActiveQuery
     */
    public function getAccessCodes()
    {
        return $this->hasMany(AccessCodes::class, ['reservation_id' => 'id']); //linha com erro - 192
    }

    /**
     * Gets query for [[Customer]].
     * @return \yii\db\ActiveQuery
     */
    public function getCustomer()
    {
        return $this->hasOne(Customer::class, ['id' => 'customer_id']);
    }

    /**
     * Gets query for [[HorariosControles]].
     * @return \yii\db\ActiveQuery
     */
    public function getHorariosControles()
    {
        return $this->hasMany(HorariosControle::class, ['reservation_id' => 'id']); //linha com erro - 210
    }

    /**
     * Gets query for [[Invoices]].
     * @return \yii\db\ActiveQuery
     */
    public function getInvoices()
    {
        return $this->hasMany(Invoices::class, ['reservation_id' => 'id']); //linha com erro - 219
    }

    /**
     * Gets query for [[Items]].
     * @return \yii\db\ActiveQuery
     */
    public function getItems()
    {
        return $this->hasMany(Economato::class, ['id' => 'item_id'])->viaTable('reservation_items', ['reservation_id' => 'id']); //linha com erro - 228
    }

    /**
     * Gets query for [[Items0]].
     * @return \yii\db\ActiveQuery
     */
    public function getItems0()
    {
        return $this->hasMany(RoomItems::class, ['id' => 'item_id'])->viaTable('reservation_room_items', ['reservation_id' => 'id']); //linha com erro - 237
    }

    /**
     * Gets query for [[Payments]].
     * @return \yii\db\ActiveQuery
     */
    public function getPayments()
    {
        return $this->hasMany(Payments::class, ['reservation_id' => 'id']); //linha com erro - 246
    }

    /**
     * Gets query for [[ReservationItems]].
     * @return \yii\db\ActiveQuery
     */
    public function getReservationItems()
    {
        return $this->hasMany(ReservationItems::class, ['reservation_id' => 'id']); ////linha com erro - 255
    }

    /**
     * Gets query for [[ReservationRoomItems]].
     * @return \yii\db\ActiveQuery
     */
    public function getReservationRoomItems()
    {
        return $this->hasMany(ReservationRoomItems::class, ['reservation_id' => 'id']); //linha com erro - 264
    }

    /**
     * Gets query for [[Room]].
     * @return \yii\db\ActiveQuery
     */
    public function getRoom()
    {
        return $this->hasOne(Room::class, ['id' => 'room_id']);
    }

    // --- FORMATAÇÃO DE SAÍDA (API) ---

    /**
     * fields(): Controla quais campos são retornados pela API.
     * O seu código original aqui estava bom.
     */
    public function fields()
    {
        $fields = parent::fields();

        // Vamos adicionar o novo código de reserva
        $fields['reservation_code'] = 'reservation_code';

        // O seu 'title' e 'color' customizados
        $fields['title'] = function ($model) {
            // Carrega o nome da Sala e do Cliente via relacionamentos
            $roomName = $model->room->nome_sala ?? 'Mesa Indefinida';
            $customerName = $model->customer->nome ?? 'Cliente Desconhecido';
            return "Reserva #{$model->id}: {$roomName} ({$customerName})";
        };
        $fields['start'] = 'hora_inicio_agendada';
        $fields['end'] = 'hora_fim_agendada';
        $fields['color'] = function ($model) {
            switch ($model->status) {
                case 'confirmada':
                    return '#4CAF50'; // Verde
                case 'pendente':
                    return '#FFC107'; // Amarelo
                default:
                    return '#2196F3'; // Azul padrão
            }
        };

        return $fields;
    }
}
