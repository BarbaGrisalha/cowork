<?php

use yii\helpers\Html;
use yii\widgets\Pjax; // Use Pjax para agendas e listagens, mantendo a experiência de SPA

/* @var $this yii\web\View */
/* @var $barItems array */ // Dados do Bar Virtual
/* @var $equipment array */ // Dados dos Equipamentos
/* @var $locations array */ // Locais disponíveis
/* @var $userReservations common\models\Reservation[] */ // Reservas do usuário

$this->title = 'Painel do Cliente | Cowork';
?>

<div class="dashboard-index">
    <h1><?= Html::encode($this->title) ?></h1>
    <p class="lead">Bem-vindo(a), <?= Yii::$app->user->identity->username ?>! Aqui está o resumo do seu Cowork.</p>

    <div class="row mt-4">
        <div class="col-lg-6">
            <h2>Agenda e Locação de Espaços</h2>
            <p>Selecione um espaço para agendar:</p>

            <?php // Aqui você renderizaria um formulário ou um widget de agenda
            // Por exemplo, um dropdown/lista de links para Location::type

            foreach ($locations as $location) {
                echo Html::a(
                    $location['name'] . ' (' . $location['type'] . ')',
                    ['/reservation/create', 'location_id' => $location['id']],
                    ['class' => 'btn btn-outline-primary m-1']
                );
            }
            ?>

            <h3 class="mt-4">Minhas Próximas Reservas</h3>
            <?php if (empty($userReservations)): ?>
                <p>Você não tem nenhuma reserva confirmada ou pendente. Vamos começar!</p>
            <?php else: ?>
                <ul class="list-group">
                    <?php foreach ($userReservations as $reservation):
                        // Uso do Eager Loading: $reservation->location está disponível SEM nova consulta ao DB
                        $locationName = $reservation->location ? $reservation->location->name : 'Local Removido';
                    ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span>
                                **<?= Html::encode($locationName) ?>**
                                <small class="text-muted"> | De: <?= Yii::$app->formatter->asDatetime($reservation->start_time) ?> - Status: <?= $reservation->status ?></small>
                            </span>
                            <?= Html::a('Cancelar', ['/reservation/cancel', 'id' => $reservation->id], [
                                'class' => 'btn btn-sm btn-danger',
                                'data' => [
                                    'confirm' => 'Tem certeza que deseja cancelar esta reserva?',
                                    'method' => 'post',
                                ],
                            ]) ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>

        <div class="col-lg-6">
            <h2>Bar Virtual (Cafeteria)</h2>
            <?= $this->render('_itemList', ['items' => $barItems]) // Componente para DRY 
            ?>

            <h2 class="mt-4">Locação de Equipamentos</h2>
            <?= $this->render('_itemList', ['items' => $equipment]) // Reutiliza o componente 
            ?>
        </div>
    </div>
</div>

<?php
// Exemplo de componente reutilizável para listagem de itens
// View: frontend/views/dashboard/_itemList.php
/*
<?php
use yii\helpers\Html;
// $items: array de Bar ou Equipamentos
?>
<ul class="list-group">
    <?php foreach ($items as $item): ?>
        <li class="list-group-item d-flex justify-content-between align-items-center">
            <?= Html::encode($item['name']) ?>
            <span class="badge bg-success rounded-pill"><?= Yii::$app->formatter->asCurrency($item['price']) ?></span>
        </li>
    <?php endforeach; ?>
</ul>
*/